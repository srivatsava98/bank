package com.cg.banking.services;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices{
	private static final String transactionType = null;
	private BankingDAOServices daoservices;
	
	public BankingServicesImpl() {
		daoservices = new BankingDAOServicesImpl();
	}
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) {
			Customer customer = new Customer(firstName, lastName, emailId, panCard, new Address(localAddressPinCode, localAddressCity, localAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState));
		return daoservices.insertCustomer(customer);
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
			CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		
		return daoservices.insertAccount(customerId, new Account(accountType, initBalance));
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
			AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account = daoservices.getAccount(customerId, accountNo);
		account.setAccountBalance(account.getAccountBalance()+amount);
		Transaction transaction = new Transaction(amount, "deposit");
		daoservices.insertTransaction(customerId, accountNo, transaction);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account = daoservices.getAccount(customerId, accountNo);
		if(pinNumber==account.getPinNumber())
			account.setAccountBalance(account.getAccountBalance()-amount);
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
		depositAmount(customerIdTo, accountNoTo, transferAmount);
		return true;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		Customer customer = daoservices.getCustomer(customerId);
		if(customer==null)
			throw new CustomerNotFoundException("Customer details with customerId "+customerId+" is not found");
		return customer;
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		Account account = daoservices.getAccount(customerId, accountNo);
		if(account==null)
			throw new AccountNotFoundException("Account number not found");
		return account;
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer[] getAllCustomerDetails() throws BankingServicesDownException {
		return daoservices.getCustomers();
	}

	@Override
	public Account[] getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		return daoservices.getAccounts(customerId);
	}

	@Override
	public Transaction[] getAccountAllTransaction(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		return daoservices.getTransactions(customerId, accountNo);
	}

	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
			CustomerNotFoundException, AccountNotFoundException, AccountBlockedException {
		return null;
	}

	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		return false;
	}

}
