package com.cg.banking.daoservices;

import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices {
	public static Customer[] customerList = new Customer[10];
	public static int CUSTOMER_ID_COUNTER=111;
	public static int CUSTOMER_IDX_COUNTER=0;
	public static int ACCOUNT_ID_COUNTER=1234567;
	static Random rand = new Random();
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		if(CUSTOMER_IDX_COUNTER==0.7*customerList.length){
			Customer temp[]=new Customer[10+customerList.length];
			System.arraycopy(customerList, 0, temp, 0, customerList.length);
			customerList = temp;
		}
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId){
				if(customerList[i].getAccountIdxCounter()==0.7*(customerList[i].getAccounts().length)){
				Account temp[]=new Account[customerList[i].getAccounts().length+10];
				System.arraycopy(customerList[i].getAccounts(), 0, temp, 0, customerList[i].getAccounts().length);
				}		
		account.setAccountNo(ACCOUNT_ID_COUNTER++);
		customerList[i].getAccounts()[customerList[i].getAccountIdxCounter()]=account;
		return account.getAccountNo();
			}
		return 0;
	}
		
	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId){
				for(int j=0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j]!=null&&customerList[i].getAccounts()[j].getAccountNo()==account.getAccountNo())
						customerList[i].getAccounts()[customerList[i].getAccountIdxCounter()]=account;
						return true;
					}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId){
				for(int j=0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j]!=null&&customerList[i].getAccounts()[j].getAccountNo()==account.getAccountNo())
						customerList[i].getAccounts()[j].setPinNumber(rand.nextInt(10000));
				return account.getPinNumber();
			}
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId){
				for(int j = 0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j]!=null&&customerList[i].getAccounts()[j].getAccountNo()==accountNo)			
						for(int k=0;k<customerList[i].getAccounts()[j].getTransactions().length;k++)
							if(customerList[i].getAccounts()[j].getTransactions()[k]!=null&&customerList[i].getAccounts()[j].getTransactions()[k]==transaction)
								customerList[i].getAccounts()[j].getTransactions()[k]=transaction;
				return true;
			}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerId==customerList[i].getCustomerId()){
				customerList[i]=null;
				for (int j=0;j<customerList.length;j++) 
					if(customerList[j]==null)
						for (int j2 = j+1; j2 < customerList.length; j2++) 
							if(customerList[j2]!=null){
								customerList[j]=customerList[j2];
								customerList[j2]=null;
								break;
							}
				return true;
			}
		return false;
	}	

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId){
				return customerList[i];
			}
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId){
				for(int j=0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j]!=null&&customerList[i].getAccounts()[j].getAccountNo()==accountNo)
					return customerList[i].getAccounts()[j];	
			}
		return null;
	}

	@Override
	public Customer[] getCustomers() {
		return customerList;
	}

	@Override
	public Account[] getAccounts(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i].getCustomerId()==customerId){
				return customerList[i].getAccounts();
			}
		return null;
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i].getCustomerId()==customerId){
				for(int j=0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j].getAccountNo()==accountNo)
						return customerList[i].getAccounts()[j].getTransactions();
			}
		return null;	
	}
	}
