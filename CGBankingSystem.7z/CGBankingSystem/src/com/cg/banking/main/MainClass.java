package com.cg.banking.main;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		BankingServicesImpl bankingServicesImpl = new BankingServicesImpl();
		int a=bankingServicesImpl.acceptCustomerDetails("M", "S", "sri@abc.com", "FFQPS2110", "Hyd", "TG", 500018, "Pune", "Maharashtra", 500018);
		long b=bankingServicesImpl.openAccount(111, "Savings", 6000);
		long c=bankingServicesImpl.openAccount(111, "Savings", 8000);
	System.out.println(b+" "+c);
		//System.out.println(bankingServicesImpl.getAccountDetails(1111, b).getAccountBalance());
	}
}
